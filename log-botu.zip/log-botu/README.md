# BURAYA_BOTUNUZUN_ADI

**BURAYA_BOTUNUZUN_ADI**, Discord sunucunuzdaki önemli olayları kaydeden, gelişmiş ve profesyonel bir log botudur. Koyu mavi güvenlik temalı embed mesajları ile sunucunuzdaki tüm değişiklikleri anlık olarak takip eder.

## Özellikler

- Rol ekleme / çıkarma logları (yetkili bilgisi ile)
- Kullanıcı adı değişikliği logları
- Mesaj silme / düzenleme logları
- Kanal oluşturma / silme / ad değiştirme logları
- Ban / ban kaldırma logları
- Ses giriş / çıkış / geçiş logları
- Rol oluşturma / silme / güncelleme logları
- Emoji ekleme / silme logları
- Thread açma / silme logları
- Audit log entegrasyonu ile işlemi yapan yetkiliyi tespit etme
- Gelişmiş embed tasarımı
- Türkçe dil desteği
- `/log-kanal` komutu ile yöneticinin seçtiği kanala log atar
- Sunucuya katılınca otomatik kurulum mesajı gönderir
- Her sunucuya özel ayrı log kanalı (JSON tabanlı)

## Kurulum

### Gereksinimler

- [Node.js](https://nodejs.org/) v18 veya üzeri
- Bir Discord bot tokeni ([Discord Developer Portal](https://discord.com/developers/applications))

### 1. Projeyi klonlayın

```bash
git clone https://github.com/gorevsitesi-dev/logix-guard-alt-yapi.git
cd logix-guard
```

### 2. Bağımlılıkları yükleyin

```bash
npm install
```

### 3. .env dosyasını oluşturun

```bash
cp .env.example .env
```

Ardından `.env` dosyasını düzenleyip bot tokeninizi girin:

```
TOKEN=bot_tokeninizi_girin
```

### 4. Botu çalıştırın

```bash
npm start
```

### PM2 ile çalıştırma (önerilen)

```bash
npm install -g pm2
pm2 start src/index.js --name "BURAYA_BOTUNUZUN_ADI"
pm2 save
pm2 startup
```

## Discord Developer Portal Ayarları

### Açılması Gereken Intentler

Botunuzun düzgün çalışması için [Discord Developer Portal](https://discord.com/developers/applications) üzerinden aşağıdaki intentleri etkinleştirmelisiniz:

1. **Guild Members Intent** — Sunucu üyelerini ve rollerini takip etmek için
2. **Message Content Intent** — Mesaj içeriklerini okumak için
3. **Guild Moderation Intent** — Ban / kick olaylarını takip etmek için
4. **Guild Voice States Intent** — Ses kanalı olaylarını takip etmek için

### Gerekli Bot Yetkileri

- `View Audit Log` — Denetim kaydını okumak için
- `View Channels` — Kanalları görmek için
- `Send Messages` — Mesaj göndermek için
- `Embed Links` — Embed mesaj göndermek için
- `Read Message History` — Mesaj geçmişini okumak için

## Komutlar

| Komut               | Açıklama                                          |
| ------------------- | ------------------------------------------------- |
| `/log-kanal #kanal` | Log mesajlarının gönderileceği kanalı ayarlar     |
| `/help`             | Bot komutları ve özellikleri hakkında bilgi verir |
| `/istatistik`       | Bot istatistiklerini gösterir                     |

## Proje Yapısı

```
logix-guard/
├── src/
│   ├── index.js              # Ana bot dosyası
│   ├── config.js             # Yapılandırma (token .env'den alınır)
│   ├── commands/
│   │   ├── setlog.js         # /log-kanal komutu
│   │   ├── help.js           # /help komutu
│   │   └── istatistik.js     # /istatistik komutu
│   ├── events/
│   │   ├── ready.js          # Bot hazır olunca
│   │   ├── guildCreate.js    # Sunucuya katılma
│   │   ├── guildDelete.js    # Sunucudan ayrılma
│   │   ├── guildMemberAdd.js # Üye katılma
│   │   ├── guildMemberRemove.js # Üye ayrılma/kick
│   │   ├── guildMemberUpdate.js # Rol/nick değişikliği
│   │   ├── guildUpdate.js    # Sunucu adı değişikliği
│   │   ├── guildBanAdd.js    # Ban
│   │   ├── guildBanRemove.js # Ban kaldırma
│   │   ├── messageDelete.js  # Mesaj silme
│   │   ├── messageUpdate.js  # Mesaj düzenleme
│   │   ├── messageDeleteBulk.js # Toplu mesaj silme
│   │   ├── channelCreate.js  # Kanal oluşturma
│   │   ├── channelDelete.js  # Kanal silme
│   │   ├── channelUpdate.js  # Kanal güncelleme
│   │   ├── voiceStateUpdate.js # Ses olayları
│   │   ├── roleCreate.js     # Rol oluşturma
│   │   ├── roleDelete.js     # Rol silme
│   │   ├── roleUpdate.js     # Rol güncelleme
│   │   ├── emojiCreate.js    # Emoji ekleme
│   │   ├── emojiDelete.js    # Emoji silme
│   │   ├── threadCreate.js   # Thread açma
│   │   └── threadDelete.js   # Thread silme
│   └── utils/
│       ├── sendLog.js        # Log gönderme yardımcısı
│       ├── guildConfig.js    # Sunucu yapılandırma (JSON)
│       ├── formatDate.js     # Tarih biçimlendirme
│       └── roleCache.js      # Rol önbelleği
├── data/
│   └── guilds.json           # Sunucu log kanalı ayarları (otomatik oluşur)
├── .env.example
├── .gitignore
├── package.json
└── README.md
```

## Lisans

MIT

---

**Not:** `data/guilds.json` dosyası bot çalıştıkça otomatik oluşur. Kendi sunucu ID'lerinizi içerdiği için `.gitignore`'a eklenmemiştir, commit'lememeye dikkat edin.
