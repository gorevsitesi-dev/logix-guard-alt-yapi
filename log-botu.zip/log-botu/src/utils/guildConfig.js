const fs = require("fs");
const path = require("path");
const config = require("../config");

const configPath = path.join(__dirname, "..", "..", "data", "guilds.json");

function ensureDir() {
  const dir = path.dirname(configPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function load() {
  try {
    ensureDir();
    if (!fs.existsSync(configPath)) {
      fs.writeFileSync(configPath, "{}", "utf-8");
      return {};
    }
    const raw = fs.readFileSync(configPath, "utf-8");
    return JSON.parse(raw);
  } catch (error) {
    console.error("[BURAYA_BOTUNUZUN_ADI] Config dosyasi okunamadi, sifirlaniyor:", error.message);
    try {
      fs.writeFileSync(configPath, "{}", "utf-8");
    } catch {}
    return {};
  }
}

function save(data) {
  try {
    ensureDir();
    fs.writeFileSync(configPath, JSON.stringify(data, null, 2), "utf-8");
  } catch (error) {
    console.error("[BURAYA_BOTUNUZUN_ADI] Config kayit hatasi:", error.message);
  }
}

function getLogChannel(guildId) {
  const data = load();
  return data[guildId]?.logChannelId || config.defaultLogChannel || null;
}

function setLogChannel(guildId, channelId) {
  const data = load();
  if (!data[guildId]) {
    data[guildId] = {};
  }
  data[guildId].logChannelId = channelId;
  save(data);
}

function removeGuild(guildId) {
  const data = load();
  delete data[guildId];
  save(data);
}

function getAll() {
  return load();
}

module.exports = { getLogChannel, setLogChannel, removeGuild, getAll };
