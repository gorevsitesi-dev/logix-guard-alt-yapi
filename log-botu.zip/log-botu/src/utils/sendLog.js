const { EmbedBuilder } = require("discord.js");
const { getLogChannel, removeGuild } = require("./guildConfig");

async function sendLog(client, guildId, data) {
  try {
    const channelId = getLogChannel(guildId);
    if (!channelId) return;

    const channel = await client.channels.fetch(channelId);
    if (!channel) return;

    const embed = new EmbedBuilder()
      .setColor(data.color || 0x0a1a3a)
      .setTitle(data.title || "Log Olayı")
      .setTimestamp()
      .setFooter({
        text: "BURAYA_BOTUNUZUN_ADI • Gelişmiş Sunucu Log Sistemi",
        iconURL: client.user.displayAvatarURL(),
      });

    if (data.fields) {
      embed.addFields(data.fields);
    }

    if (data.description) {
      embed.setDescription(data.description);
    }

    embed.addFields({
      name: "Sunucu",
      value: `**${channel.guild.name}**`,
      inline: true,
    });

    await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
  } catch (error) {
    if (error.code === 50001) {
      console.log("[BURAYA_BOTUNUZUN_ADI] Log kanalına erişilemiyor.");
    } else if (error.code === 10003 || error.code === 10013) {
      console.log("[BURAYA_BOTUNUZUN_ADI] Log kanalı bulunamadı, yapılandırma sıfırlanıyor.");
      removeGuild(guildId);
    } else {
      console.error("[BURAYA_BOTUNUZUN_ADI] Log gönderme hatası:", error.message);
    }
  }
}

module.exports = { sendLog };
