const { ChannelType } = require("discord.js");

const channelTypes = {
  [ChannelType.GuildText]: "Yazı Kanalı",
  [ChannelType.GuildVoice]: "Ses Kanalı",
  [ChannelType.GuildCategory]: "Kategori",
  [ChannelType.GuildAnnouncement]: "Duyuru Kanalı",
  [ChannelType.GuildForum]: "Forum",
  [ChannelType.GuildStageVoice]: "Sahne Kanalı",
  [ChannelType.GuildDirectory]: "Dizin",
  [ChannelType.GuildMedia]: "Medya Kanalı",
};

function getChannelTypeName(type) {
  return channelTypes[type] || "Bilinmiyor";
}

module.exports = { channelTypes, getChannelTypeName };
