const cache = new Map();

function getMemberRoles(guildId, memberId) {
  const key = `${guildId}-${memberId}`;
  return cache.get(key);
}

function setMemberRoles(guildId, memberId, roles) {
  const key = `${guildId}-${memberId}`;
  cache.set(key, new Set(roles));
}

function deleteMember(guildId, memberId) {
  const key = `${guildId}-${memberId}`;
  cache.delete(key);
}

module.exports = { getMemberRoles, setMemberRoles, deleteMember };
