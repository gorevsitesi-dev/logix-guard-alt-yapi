const { SlashCommandBuilder, EmbedBuilder, MessageFlags, version } = require("discord.js");
const fs = require("fs");
const path = require("path");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("istatistik")
    .setDescription("BURAYA_BOTUNUZUN_ADI istatistiklerini gösterir"),

  async execute(interaction) {
    try {
      const client = interaction.client;
      const uptime = formatUptime(client.uptime);
      const guildCount = client.guilds.cache.size;
      const userCount = client.guilds.cache.reduce((a, g) => a + g.memberCount, 0);
      const channelCount = client.guilds.cache.reduce(
        (a, g) => a + g.channels.cache.size,
        0
      );
      const eventCount = fs
        .readdirSync(path.join(__dirname, "..", "events"))
        .filter((f) => f.endsWith(".js")).length;
      const commandCount = fs
        .readdirSync(path.join(__dirname))
        .filter((f) => f.endsWith(".js")).length;
      const rawPing = client.ws.ping;
      const ping = rawPing !== null && rawPing !== -1 ? `${rawPing}ms` : "N/A";
      const memory = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(1);
      const platformNames = {
        win32: "Windows",
        linux: "Linux",
        darwin: "macOS",
      };
      const platform = platformNames[process.platform] || process.platform;

      const embed = new EmbedBuilder()
        .setColor(0x0a1a3a)
        .setTitle("BURAYA_BOTUNUZUN_ADI • İstatistik")
        .setThumbnail(client.user.displayAvatarURL())
        .addFields(
          { name: "Bot Adı", value: `${client.user.tag}`, inline: true },
          { name: "Bot ID", value: `${client.user.id}`, inline: true },
          { name: "Sunucu Sayısı", value: `${guildCount}`, inline: true },
          { name: "Kullanıcı Sayısı", value: `${userCount.toLocaleString()}`, inline: true },
          { name: "Kanal Sayısı", value: `${channelCount.toLocaleString()}`, inline: true },
          { name: "Komut Sayısı", value: `${commandCount}`, inline: true },
          { name: "Event Sayısı", value: `${eventCount}`, inline: true },
          { name: "Gecikme (Ping)", value: ping, inline: true },
          { name: "Çalışma Süresi", value: uptime, inline: true },
          { name: "discord.js", value: `v${version}`, inline: true },
          { name: "Node.js", value: `${process.version}`, inline: true },
          { name: "Platform", value: platform, inline: true },
          { name: "Bellek Kullanımı", value: `${memory} MB`, inline: true }
        )
        .setFooter({
          text: "BURAYA_BOTUNUZUN_ADI • Gelişmiş Sunucu Log Sistemi",
        })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] /istatistik hatası:", error.message);
      await interaction.reply({
        content: "Bir hata oluştu.",
        flags: MessageFlags.Ephemeral,
      });
    }
  },
};

function formatUptime(ms) {
  const seconds = Math.floor(ms / 1000);
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  return `${days}g ${hours}s ${minutes}d ${secs}sn`;
}
