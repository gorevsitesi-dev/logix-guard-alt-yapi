const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, MessageFlags, ChannelType, PermissionsBitField } = require("discord.js");
const { setLogChannel, getLogChannel, removeGuild } = require("../utils/guildConfig");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("log-kanal")
    .setDescription("Log mesajlarının gönderileceği kanalı belirler, sıfırlar veya gösterir")
    .addChannelOption((option) =>
      option
        .setName("kanal")
        .setDescription("Log kanalı (belirtilmezse mevcut ayar gösterilir)")
        .setRequired(false)
    )
    .addStringOption((option) =>
      option
        .setName("işlem")
        .setDescription("Yapılacak işlem")
        .addChoices(
          { name: "Sıfırla", value: "reset" },
          { name: "Göster", value: "show" }
        )
        .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    try {
      const channel = interaction.options.getChannel("kanal");
      const action = interaction.options.getString("işlem");

      if (action === "reset") {
        removeGuild(interaction.guildId);
        return interaction.reply({
          content: "Log kanalı sıfırlandı. Artık log mesajı gönderilmeyecek.",
          flags: MessageFlags.Ephemeral,
        });
      }

      if (action === "show") {
        const current = getLogChannel(interaction.guildId);
        return interaction.reply({
          content: current ? `Mevcut log kanalı: <#${current}>` : "Henüz bir log kanalı ayarlanmamış.",
          flags: MessageFlags.Ephemeral,
        });
      }

      if (!channel) {
        const current = getLogChannel(interaction.guildId);
        return interaction.reply({
          content: current
            ? `Mevcut log kanalı: <#${current}>\nDeğiştirmek için bir kanal belirtin: \`/log-kanal #kanal\``
            : "Bir kanal belirtin: `/log-kanal #kanal`",
          flags: MessageFlags.Ephemeral,
        });
      }

      if (channel.type !== ChannelType.GuildText && channel.type !== ChannelType.GuildAnnouncement) {
        return interaction.reply({
          content: "Lütfen bir **yazı kanalı** seçin!",
          flags: MessageFlags.Ephemeral,
        });
      }

      const botMember = interaction.guild.members.me;
      const permissions = channel.permissionsFor(botMember);
      if (!permissions || !permissions.has(PermissionsBitField.Flags.SendMessages) || !permissions.has(PermissionsBitField.Flags.EmbedLinks)) {
        return interaction.reply({
          content: `Botun <#${channel.id}> kanalında **Mesaj Gönder** ve **Embed Link** yetkileri yok. Lütfen kanal izinlerini kontrol edin.`,
          flags: MessageFlags.Ephemeral,
        });
      }

      setLogChannel(interaction.guildId, channel.id);

      const embed = new EmbedBuilder()
        .setColor(0x0a1a3a)
        .setTitle("Log Kanalı Ayarlandı")
        .setDescription(`Log mesajları artık **${channel}** kanalına gönderilecek.`)
        .addFields(
          {
            name: "Kanal",
            value: `${channel} (${channel.id})`,
            inline: true,
          },
          {
            name: "Ayarlayan",
            value: `${interaction.user.tag} (${interaction.user.id})`,
            inline: true,
          }
        )
        .setFooter({
          text: "BURAYA_BOTUNUZUN_ADI • Gelişmiş Sunucu Log Sistemi",
        })
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });

      try {
        await channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor(0x0a1a3a)
              .setTitle("BURAYA_BOTUNUZUN_ADI Aktif")
              .setDescription(
                "Bu kanal **BURAYA_BOTUNUZUN_ADI** log mesajları için ayarlandı.\n" +
                "Sunucudaki tüm önemli olaylar buraya kaydedilecek."
              )
              .setFooter({
                text: "BURAYA_BOTUNUZUN_ADI • Gelişmiş Sunucu Log Sistemi",
              })
              .setTimestamp(),
          ],
        });
      } catch {
        await interaction.followUp({
          content: `Kanal ayarlandı ancak <#${channel.id}> kanalına test mesajı gönderilemedi. Botun kanala erişimi olduğundan emin olun.`,
          flags: MessageFlags.Ephemeral,
        });
      }
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] /log-kanal hatası:", error.message);
      const replyOpts = { content: "Bir hata oluştu. Lütfen tekrar deneyin.", flags: MessageFlags.Ephemeral };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(replyOpts);
      } else {
        await interaction.reply(replyOpts);
      }
    }
  },
};
