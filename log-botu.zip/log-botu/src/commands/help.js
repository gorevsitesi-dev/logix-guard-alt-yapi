const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require("discord.js");
const fs = require("fs");
const path = require("path");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("help")
    .setDescription("BURAYA_BOTUNUZUN_ADI komutları ve özellikleri hakkında bilgi verir"),

  async execute(interaction) {
    try {
      const eventCount = fs
        .readdirSync(path.join(__dirname, "..", "events"))
        .filter((f) => f.endsWith(".js")).length;

      const embed = new EmbedBuilder()
        .setColor(0x0a1a3a)
        .setTitle("BURAYA_BOTUNUZUN_ADI • Yardım")
        .setDescription(
          "Gelişmiş Discord sunucu log botu. Sunucunuzdaki tüm önemli olayları kaydeder."
        )
        .addFields(
          {
            name: "Komutlar",
            value:
              "`/log-kanal` — Log kanalını ayarlar, sıfırlar veya gösterir\n" +
              "• `/log-kanal #kanal` — Belirtilen kanalı log kanalı yapar\n" +
              "• `/log-kanal işlem:sıfırla` — Log kanalını sıfırlar\n" +
              "• `/log-kanal işlem:göster` — Mevcut log kanalını gösterir\n" +
              "`/help` — Bu menüyü gösterir\n" +
              "`/istatistik` — Bot istatistiklerini gösterir\n" +
              "`/ping` — Bot gecikmesini gösterir",
            inline: false,
          },
          {
            name: "Log Türleri",
            value:
              "• Rol ekleme / çıkarma (toplu işlemler tek mesajda)\n" +
              "• Kullanıcı adı değişikliği\n" +
              "• Mesaj silme / düzenleme / toplu silme\n" +
              "• Kanal oluşturma / silme / güncelleme (ad, konu, NSFW, yavaş mod)\n" +
              "• Ban / Ban kaldırma\n" +
              "• Ses giriş / çıkış / geçiş\n" +
              "• Ses ayarları (mikrofon/kulaklık susturma)\n" +
              "• Rol oluşturma / silme / güncelleme\n" +
              "• Emoji ekleme / silme\n" +
              "• Thread açma / silme\n" +
              "• Sunucu adı değişikliği\n" +
              `• Toplam **${eventCount}** farklı olay`,
            inline: false,
          },
          {
            name: "Kurulum",
            value:
              "1. Botu sunucuya davet edin\n" +
              "2. `/log-kanal #kanal` komutu ile log kanalını ayarlayın\n" +
              "3. Gerisini bot halleder!",
            inline: false,
          },
          {
            name: "Gerekli Bot Yetkileri",
            value:
              "• View Audit Log\n" +
              "• View Channels\n" +
              "• Send Messages\n" +
              "• Embed Links\n" +
              "• Read Message History",
            inline: false,
          }
        )
        .setFooter({
          text: "BURAYA_BOTUNUZUN_ADI • Gelişmiş Sunucu Log Sistemi",
        })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] /help hatası:", error.message);
      await interaction.reply({
        content: "Bir hata oluştu.",
        flags: MessageFlags.Ephemeral,
      });
    }
  },
};
