const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Bot gecikmesini gösterir"),

  async execute(interaction) {
    try {
      const sent = await interaction.reply({
        content: "Pong! Ölçülüyor...",
        fetchReply: true,
      });

      const wsPing = interaction.client.ws.ping;
      const wsPingDisplay = wsPing !== null && wsPing !== -1 ? `${wsPing}ms` : "N/A";
      const roundtrip = sent.createdTimestamp - interaction.createdTimestamp;

      const embed = new EmbedBuilder()
        .setColor(0x0a1a3a)
        .setTitle("Pong! 🏓")
        .addFields(
          { name: "WebSocket Gecikmesi", value: wsPingDisplay, inline: true },
          { name: "Mesaj Gidiş-Dönüş", value: `${roundtrip}ms`, inline: true },
          { name: "Çalışma Süresi", value: formatUptime(interaction.client.uptime), inline: false }
        )
        .setFooter({
          text: "BURAYA_BOTUNUZUN_ADI • Gelişmiş Sunucu Log Sistemi",
        })
        .setTimestamp();

      await interaction.editReply({ content: null, embeds: [embed] });
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] /ping hatası:", error.message);
      const replyOpts = { content: "Bir hata oluştu.", flags: MessageFlags.Ephemeral };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(replyOpts);
      } else {
        await interaction.reply(replyOpts);
      }
    }
  },
};

function formatUptime(ms) {
  const seconds = Math.floor(ms / 1000);
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  return `${days}g ${hours}s ${minutes}d ${secs}sn`;
}
