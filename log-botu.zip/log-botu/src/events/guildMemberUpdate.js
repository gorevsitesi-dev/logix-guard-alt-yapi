const { Events, AuditLogEvent } = require("discord.js");
const { sendLog } = require("../utils/sendLog");
const { formatDate } = require("../utils/formatDate");
const { getMemberRoles, setMemberRoles } = require("../utils/roleCache");

module.exports = {
  name: Events.GuildMemberUpdate,
  once: false,
  async execute(oldMember, newMember) {
    try {
      const now = formatDate(new Date());

      if (oldMember.nickname !== newMember.nickname) {
        let nickExecutor = null;

        try {
          const auditLogs = await newMember.guild.fetchAuditLogs({
            type: AuditLogEvent.MemberUpdate,
            limit: 5,
          });
          const entry = auditLogs.entries
            .filter((e) => e.target?.id === newMember.id)
            .filter((e) => Date.now() - e.createdTimestamp < 20000)
            .first();

          if (entry) {
            nickExecutor = entry.executor;
          }
        } catch (error) {
          if (error.code !== 50013) console.warn("[BURAYA_BOTUNUZUN_ADI] Denetim kaydı alınamadı:", error.message);
        }

        const executorName = nickExecutor
          ? `${nickExecutor.tag} (${nickExecutor.id})`
          : "Bilinmiyor";

        await sendLog(newMember.client, newMember.guild.id, {
          title: "Kullanıcı Adı Değiştirildi",
          color: 0xf39c12,
          fields: [
            { name: "Kullanıcı", value: `${newMember.user.tag} (${newMember.id})`, inline: true },
            { name: "Yetkili", value: executorName, inline: true },
            { name: "Eski Kullanıcı Adı", value: oldMember.nickname || "Ayarlanmamış", inline: true },
            { name: "Yeni Kullanıcı Adı", value: newMember.nickname || "Ayarlanmamış", inline: true },
            { name: "Tarih / Saat", value: now, inline: false },
          ],
        });
      }

      const guildId = newMember.guild.id;
      const memberId = newMember.id;
      const currentRoles = new Set(newMember.roles.cache.keys());

      let previousRoles = getMemberRoles(guildId, memberId);
      if (!previousRoles) {
        previousRoles = new Set(oldMember.roles.cache.keys());
      }

      const addedRoles = [];
      for (const roleId of currentRoles) {
        if (!previousRoles.has(roleId)) {
          addedRoles.push(roleId);
        }
      }

      const removedRoles = [];
      for (const roleId of previousRoles) {
        if (!currentRoles.has(roleId)) {
          removedRoles.push(roleId);
        }
      }

      setMemberRoles(guildId, memberId, currentRoles);

      if (addedRoles.length === 0 && removedRoles.length === 0) return;

      let executor = null;
      try {
        const auditLogs = await newMember.guild.fetchAuditLogs({
          type: AuditLogEvent.MemberRoleUpdate,
          limit: 5,
        });
        const entry = auditLogs.entries.find(
          (e) => e.target?.id === newMember.id
        );
        if (entry && Date.now() - entry.createdTimestamp < 20000) {
          executor = entry.executor;
        }
      } catch (error) {
        if (error.code !== 50013) console.warn("[BURAYA_BOTUNUZUN_ADI] Denetim kaydı alınamadı:", error.message);
      }

      const executorName = executor
        ? `${executor.tag} (${executor.id})`
        : "Bilinmiyor";

      if (addedRoles.length > 0) {
        await sendLog(newMember.client, newMember.guild.id, {
          title: `Rol Verildi (${addedRoles.length} adet)`,
          color: 0x2ecc71,
          fields: [
            { name: "Yetkili", value: executorName, inline: true },
            { name: "Kullanıcı", value: `${newMember.user.tag} (${newMember.id})`, inline: true },
            { name: "Verilen Roller", value: addedRoles.map((r) => `<@&${r}>`).join(", "), inline: false },
            { name: "Tarih / Saat", value: now, inline: false },
          ],
        });
      }

      if (removedRoles.length > 0) {
        await sendLog(newMember.client, newMember.guild.id, {
          title: `Rol Alındı (${removedRoles.length} adet)`,
          color: 0xe74c3c,
          fields: [
            { name: "Yetkili", value: executorName, inline: true },
            { name: "Kullanıcı", value: `${newMember.user.tag} (${newMember.id})`, inline: true },
            { name: "Alınan Roller", value: removedRoles.map((r) => `<@&${r}>`).join(", "), inline: false },
            { name: "Tarih / Saat", value: now, inline: false },
          ],
        });
      }
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] GuildMemberUpdate hatası:", error.message);
    }
  },
};
