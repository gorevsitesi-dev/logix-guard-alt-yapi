const { Events, AuditLogEvent } = require("discord.js");
const { sendLog } = require("../utils/sendLog");
const { formatDate } = require("../utils/formatDate");
const { deleteMember } = require("../utils/roleCache");

module.exports = {
  name: Events.GuildMemberRemove,
  once: false,
  async execute(member) {
    try {
      deleteMember(member.guild.id, member.id);

      let executor = null;
      let kick = false;

      try {
        const auditLogs = await member.guild.fetchAuditLogs({
          type: AuditLogEvent.MemberKick,
          limit: 5,
        });
        const entry = auditLogs.entries.find(
          (e) => e.target?.id === member.id
        );
        if (entry) {
          executor = entry.executor;
          kick = true;
        }
      } catch (error) {
        if (error.code !== 50013) console.warn("[BURAYA_BOTUNUZUN_ADI] Denetim kaydı alınamadı:", error.message);
      }

      if (kick) {
        const executorName = executor
          ? `${executor.tag} (${executor.id})`
          : "Bilinmiyor";

        return await sendLog(member.client, member.guild.id, {
          title: "Kullanıcı Kicklendi",
          color: 0xe74c3c,
          fields: [
            { name: "Kullanıcı", value: `${member.user.tag} (${member.id})`, inline: true },
            { name: "Yetkili", value: executorName, inline: true },
            { name: "Tarih / Saat", value: formatDate(new Date()), inline: false },
          ],
        });
      }

      await sendLog(member.client, member.guild.id, {
        title: "Kullanıcı Ayrıldı",
        color: 0xe74c3c,
        fields: [
          { name: "Kullanıcı", value: `${member.user.tag} (${member.id})`, inline: true },
          { name: "Ayrılma Nedeni", value: "Sunucudan ayrıldı", inline: true },
          { name: "Tarih / Saat", value: formatDate(new Date()), inline: false },
        ],
      });
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] GuildMemberRemove hatası:", error.message);
    }
  },
};
