const { Events, ActivityType } = require("discord.js");
const { removeGuild } = require("../utils/guildConfig");

module.exports = {
  name: Events.ClientReady,
  once: true,
  async execute(client) {
    console.log(`BURAYA_BOTUNUZUN_ADI aktif: ${client.user.tag}`);

    client.user.setPresence({ status: "dnd" });

    client.user.setActivity("Sunucuyu Koruyor", {
      type: ActivityType.Playing,
    });

    try {
      const commands = client.commands.map((cmd) => cmd.data.toJSON());
      await client.application.commands.set(commands);
      console.log(`[BURAYA_BOTUNUZUN_ADI] ${commands.length} komut kaydedildi.`);
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] Komut kayıt hatası:", error.message);
    }

    const { getAll } = require("../utils/guildConfig");
    const configs = getAll();
    const guildIds = Object.keys(configs);

    for (const guildId of guildIds) {
      const guild = client.guilds.cache.get(guildId);
      if (!guild) continue;

      const channelId = configs[guildId]?.logChannelId;
      if (!channelId) continue;

      try {
        const channel = await client.channels.fetch(channelId);
        if (!channel) {
          removeGuild(guildId);
          continue;
        }

        console.log(`[BURAYA_BOTUNUZUN_ADI] ${guild.name} icin log kanali dogrulandi.`);
      } catch {
        console.warn(`[BURAYA_BOTUNUZUN_ADI] ${guild.name} icin log kanali bulunamadi, temizleniyor.`);
        removeGuild(guildId);
      }
    }

    if (guildIds.length > 0) {
      console.log(`[BURAYA_BOTUNUZUN_ADI] ${guildIds.length} sunucu icin log kanallari kontrol edildi.`);
    }
  },
};
