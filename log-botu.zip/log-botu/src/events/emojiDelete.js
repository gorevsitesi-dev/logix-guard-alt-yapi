const { Events, AuditLogEvent } = require("discord.js");
const { sendLog } = require("../utils/sendLog");
const { formatDate } = require("../utils/formatDate");

module.exports = {
  name: Events.GuildEmojiDelete,
  once: false,
  async execute(emoji) {
    try {
      let executor = null;

      try {
        const auditLogs = await emoji.guild.fetchAuditLogs({
          type: AuditLogEvent.EmojiDelete,
          limit: 5,
        });
        const entry = auditLogs.entries.first();
        if (entry) executor = entry.executor;
      } catch (error) {
        if (error.code !== 50013) console.warn("[BURAYA_BOTUNUZUN_ADI] Denetim kaydı alınamadı:", error.message);
      }

      const executorName = executor
        ? `${executor.tag} (${executor.id})`
        : "Bilinmiyor";

      await sendLog(emoji.client, emoji.guild.id, {
        title: "Emoji Silindi",
        color: 0xe74c3c,
        fields: [
          { name: "Emoji Adı", value: emoji.name, inline: true },
          { name: "Animasyonlu", value: emoji.animated ? "Evet" : "Hayır", inline: true },
          { name: "Yetkili", value: executorName, inline: false },
          { name: "Tarih / Saat", value: formatDate(new Date()), inline: false },
        ],
      });
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] EmojiDelete hatası:", error.message);
    }
  },
};
