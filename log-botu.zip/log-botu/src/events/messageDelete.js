const { Events } = require("discord.js");
const { sendLog } = require("../utils/sendLog");
const { formatDate } = require("../utils/formatDate");

module.exports = {
  name: Events.MessageDelete,
  once: false,
  async execute(message) {
    try {
      if (message.author?.bot) return;

      const content = message.content
        ? message.content
        : "İçerik alınamadı";

      await sendLog(message.client, message.guild?.id, {
        title: "Mesaj Silindi",
        color: 0xe74c3c,
        fields: [
          {
            name: "Mesaj Sahibi",
            value: `${message.author?.tag || "Bilinmiyor"} (${message.author?.id || "?"})`,
            inline: true,
          },
          { name: "Kanal", value: `<#${message.channelId}>`, inline: true },
          { name: "Mesaj İçeriği", value: `\`\`\`${content}\`\`\``, inline: false },
          { name: "Tarih / Saat", value: formatDate(new Date()), inline: false },
        ],
      });
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] Mesaj silme log hatası:", error.message);
    }
  },
};
