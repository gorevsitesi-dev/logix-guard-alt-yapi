const { Events, AuditLogEvent } = require("discord.js");
const { sendLog } = require("../utils/sendLog");
const { formatDate } = require("../utils/formatDate");

module.exports = {
  name: Events.GuildBanRemove,
  once: false,
  async execute(ban) {
    try {
      let executor = null;

      try {
        const auditLogs = await ban.guild.fetchAuditLogs({
          type: AuditLogEvent.MemberBanRemove,
          limit: 5,
        });

        const entry = auditLogs.entries.find(
          (e) => e.target?.id === ban.user.id
        );

        if (entry) {
          executor = entry.executor;
        }
      } catch (error) {
        if (error.code !== 50013) console.warn("[BURAYA_BOTUNUZUN_ADI] Denetim kaydı alınamadı:", error.message);
      }

      const executorName = executor
        ? `${executor.tag} (${executor.id})`
        : "Bilinmiyor";

      await sendLog(ban.client, ban.guild.id, {
        title: "Ban Kaldırıldı",
        color: 0x2ecc71,
        fields: [
          {
            name: "Kullanıcı",
            value: `${ban.user.tag} (${ban.user.id})`,
            inline: true,
          },
          { name: "Yetkili", value: executorName, inline: true },
          { name: "Tarih / Saat", value: formatDate(new Date()), inline: false },
        ],
      });
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] Ban kaldırma log hatası:", error.message);
    }
  },
};
