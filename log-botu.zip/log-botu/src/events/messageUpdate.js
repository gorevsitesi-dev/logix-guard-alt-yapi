const { Events } = require("discord.js");
const { sendLog } = require("../utils/sendLog");
const { formatDate } = require("../utils/formatDate");

module.exports = {
  name: Events.MessageUpdate,
  once: false,
  async execute(oldMessage, newMessage) {
    try {
      if (oldMessage.author?.bot) return;
      if (oldMessage.content === newMessage.content) return;
      if (!oldMessage.content || !newMessage.content) return;

      await sendLog(newMessage.client, newMessage.guild?.id, {
        title: "Mesaj Düzenlendi",
        color: 0xf39c12,
        fields: [
          {
            name: "Mesaj Sahibi",
            value: `${oldMessage.author?.tag || "Bilinmiyor"} (${oldMessage.author?.id || "?"})`,
            inline: true,
          },
          { name: "Kanal", value: `<#${oldMessage.channelId}>`, inline: true },
          { name: "Eski Mesaj", value: `\`\`\`${oldMessage.content}\`\`\``, inline: false },
          { name: "Yeni Mesaj", value: `\`\`\`${newMessage.content}\`\`\``, inline: false },
          { name: "Tarih / Saat", value: formatDate(new Date()), inline: false },
        ],
      });
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] Mesaj düzenleme log hatası:", error.message);
    }
  },
};
