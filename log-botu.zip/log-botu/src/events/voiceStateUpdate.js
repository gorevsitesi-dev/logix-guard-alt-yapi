const { Events, EmbedBuilder } = require("discord.js");
const { sendLog } = require("../utils/sendLog");
const { formatDate } = require("../utils/formatDate");

module.exports = {
  name: Events.VoiceStateUpdate,
  once: false,
  async execute(oldState, newState) {
    try {
      const member = newState.member || oldState.member;
      if (!member) return;

      const now = formatDate(new Date());
      const userId = `${member.user.tag} (${member.id})`;

      if (!oldState.channelId && newState.channelId) {
        await sendLog(newState.client, newState.guild.id, {
          title: "Ses Kanalına Giriş",
          color: 0x2ecc71,
          fields: [
            { name: "Kullanıcı", value: userId, inline: true },
            { name: "Kanal", value: `<#${newState.channelId}>`, inline: true },
            { name: "Tarih / Saat", value: now, inline: false },
          ],
        });
      } else if (oldState.channelId && !newState.channelId) {
        await sendLog(newState.client, newState.guild.id, {
          title: "Ses Kanalından Çıkış",
          color: 0xe74c3c,
          fields: [
            { name: "Kullanıcı", value: userId, inline: true },
            { name: "Kanal", value: `<#${oldState.channelId}>`, inline: true },
            { name: "Tarih / Saat", value: now, inline: false },
          ],
        });
      } else if (oldState.channelId !== newState.channelId) {
        await sendLog(newState.client, newState.guild.id, {
          title: "Ses Kanalı Değiştirdi",
          color: 0xf39c12,
          fields: [
            { name: "Kullanıcı", value: userId, inline: true },
            { name: "Eski Kanal", value: `<#${oldState.channelId}>`, inline: true },
            { name: "Yeni Kanal", value: `<#${newState.channelId}>`, inline: true },
            { name: "Tarih / Saat", value: now, inline: false },
          ],
        });
      }

      const muteChanges = [];
      if (oldState.selfMute !== newState.selfMute) {
        muteChanges.push(newState.selfMute ? "Mikrofon Susturuldu" : "Mikrofon Açıldı");
      }
      if (oldState.selfDeaf !== newState.selfDeaf) {
        muteChanges.push(newState.selfDeaf ? "Kulaklık Susturuldu" : "Kulaklık Açıldı");
      }
      if (oldState.serverMute !== newState.serverMute) {
        muteChanges.push(newState.serverMute ? "Mikrofon Kapatıldı (Yetkili)" : "Mikrofon Açıldı (Yetkili)");
      }
      if (oldState.serverDeaf !== newState.serverDeaf) {
        muteChanges.push(newState.serverDeaf ? "Kulaklık Kapatıldı (Yetkili)" : "Kulaklık Açıldı (Yetkili)");
      }

      if (muteChanges.length > 0) {
        const currentChannel = newState.channelId || oldState.channelId;

        const embed = new EmbedBuilder()
          .setColor(0xf39c12)
          .setTitle("Ses Ayarları Değişti")
          .setDescription(muteChanges.map((c) => `• ${c}`).join("\n"))
          .addFields(
            { name: "Kullanıcı", value: userId, inline: true },
            { name: "Kanal", value: currentChannel ? `<#${currentChannel}>` : "Bilinmiyor", inline: true },
            { name: "Tarih / Saat", value: now, inline: false }
          )
          .setFooter({
            text: "BURAYA_BOTUNUZUN_ADI • Gelişmiş Sunucu Log Sistemi",
          })
          .setTimestamp();

        const { getLogChannel } = require("../utils/guildConfig");
        const channelId = getLogChannel(newState.guild.id);
        if (channelId) {
          try {
            const channel = await newState.client.channels.fetch(channelId);
            if (channel) {
              await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
            }
          } catch (error) {
            if (error.code !== 50013) console.warn("[BURAYA_BOTUNUZUN_ADI] Log gönderme hatası:", error.message);
          }
        }
      }
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] VoiceStateUpdate hatası:", error.message);
    }
  },
};
