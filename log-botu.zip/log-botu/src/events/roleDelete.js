const { Events, AuditLogEvent } = require("discord.js");
const { sendLog } = require("../utils/sendLog");
const { formatDate } = require("../utils/formatDate");

module.exports = {
  name: Events.GuildRoleDelete,
  once: false,
  async execute(role) {
    try {
      let executor = null;

      try {
        const auditLogs = await role.guild.fetchAuditLogs({
          type: AuditLogEvent.RoleDelete,
          limit: 5,
        });
        const entry = auditLogs.entries.first();
        if (entry) executor = entry.executor;
      } catch (error) {
        if (error.code !== 50013) console.warn("[BURAYA_BOTUNUZUN_ADI] Denetim kaydı alınamadı:", error.message);
      }

      const executorName = executor
        ? `${executor.tag} (${executor.id})`
        : "Bilinmiyor";

      await sendLog(role.client, role.guild.id, {
        title: "Rol Silindi",
        color: 0xe74c3c,
        fields: [
          { name: "Rol Adı", value: role.name, inline: true },
          { name: "Renk", value: role.hexColor, inline: true },
          { name: "Yetkili", value: executorName, inline: false },
          { name: "Tarih / Saat", value: formatDate(new Date()), inline: false },
        ],
      });
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] RoleDelete hatası:", error.message);
    }
  },
};
