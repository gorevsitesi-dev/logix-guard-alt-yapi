const { Events, AuditLogEvent } = require("discord.js");
const { sendLog } = require("../utils/sendLog");
const { formatDate } = require("../utils/formatDate");

module.exports = {
  name: Events.ChannelUpdate,
  once: false,
  async execute(oldChannel, newChannel) {
    try {
      let executor = null;

      try {
        const auditLogs = await newChannel.guild.fetchAuditLogs({
          type: AuditLogEvent.ChannelUpdate,
          limit: 5,
        });

        const entry = auditLogs.entries.first();
        if (entry) {
          executor = entry.executor;
        }
      } catch (error) {
        if (error.code !== 50013) console.warn("[BURAYA_BOTUNUZUN_ADI] Denetim kaydı alınamadı:", error.message);
      }

      const executorName = executor
        ? `${executor.tag} (${executor.id})`
        : "Bilinmiyor";

      const changes = [];

      if (oldChannel.name !== newChannel.name) {
        changes.push(`**Kanal Adı:** ${oldChannel.name} → ${newChannel.name}`);
      }

      if (oldChannel.topic !== newChannel.topic) {
        changes.push("**Kanal Konusu** değiştirildi");
      }

      if (oldChannel.nsfw !== newChannel.nsfw) {
        changes.push(newChannel.nsfw ? "**NSFW** olarak işaretlendi" : "**NSFW** kaldırıldı");
      }

      if (oldChannel.rateLimitPerUser !== newChannel.rateLimitPerUser) {
        changes.push(`**Yavaş Mod:** ${oldChannel.rateLimitPerUser || 0}sn → ${newChannel.rateLimitPerUser || 0}sn`);
      }

      if (changes.length === 0) return;

      await sendLog(newChannel.client, newChannel.guild.id, {
        title: "Kanal Güncellendi",
        color: 0xf39c12,
        fields: [
          { name: "Kanal", value: `<#${newChannel.id}> (${newChannel.name})`, inline: true },
          { name: "Yetkili", value: executorName, inline: true },
          { name: "Değişiklikler", value: changes.join("\n"), inline: false },
          { name: "Tarih / Saat", value: formatDate(new Date()), inline: false },
        ],
      });
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] Kanal güncelleme log hatası:", error.message);
    }
  },
};
