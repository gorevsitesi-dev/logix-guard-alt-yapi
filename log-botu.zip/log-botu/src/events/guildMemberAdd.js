const { Events } = require("discord.js");
const { sendLog } = require("../utils/sendLog");
const { formatDate } = require("../utils/formatDate");

module.exports = {
  name: Events.GuildMemberAdd,
  once: false,
  async execute(member) {
    try {
      const createdAgo = Math.floor(
        (Date.now() - member.user.createdTimestamp) / 86400000
      );

      await sendLog(member.client, member.guild.id, {
        title: "Kullanıcı Katıldı",
        color: 0x2ecc71,
        fields: [
          { name: "Kullanıcı", value: `${member.user.tag} (${member.id})`, inline: true },
          { name: "Hesap Yaşı", value: `${createdAgo} günlük`, inline: true },
          { name: "Tarih / Saat", value: formatDate(new Date()), inline: false },
        ],
      });
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] GuildMemberAdd hatası:", error.message);
    }
  },
};
