const { Events, AuditLogEvent } = require("discord.js");
const { sendLog } = require("../utils/sendLog");
const { formatDate } = require("../utils/formatDate");

module.exports = {
  name: Events.GuildRoleUpdate,
  once: false,
  async execute(oldRole, newRole) {
    try {
      if (oldRole.name !== newRole.name) {
        let executor = null;
        try {
          const auditLogs = await newRole.guild.fetchAuditLogs({
            type: AuditLogEvent.RoleUpdate,
            limit: 5,
          });
          const entry = auditLogs.entries.first();
          if (entry) executor = entry.executor;
        } catch (error) {
          if (error.code !== 50013) console.warn("[BURAYA_BOTUNUZUN_ADI] Denetim kaydı alınamadı:", error.message);
        }

        const executorName = executor
          ? `${executor.tag} (${executor.id})`
          : "Bilinmiyor";

        await sendLog(newRole.client, newRole.guild.id, {
          title: "Rol Adı Değiştirildi",
          color: 0xf39c12,
          fields: [
            { name: "Eski Ad", value: oldRole.name, inline: true },
            { name: "Yeni Ad", value: newRole.name, inline: true },
            { name: "Yetkili", value: executorName, inline: false },
            { name: "Tarih / Saat", value: formatDate(new Date()), inline: false },
          ],
        });
      }

      if (oldRole.hexColor !== newRole.hexColor) {
        let executor = null;
        try {
          const auditLogs = await newRole.guild.fetchAuditLogs({
            type: AuditLogEvent.RoleUpdate,
            limit: 5,
          });
          const entry = auditLogs.entries.first();
          if (entry) executor = entry.executor;
        } catch (error) {
          if (error.code !== 50013) console.warn("[BURAYA_BOTUNUZUN_ADI] Denetim kaydı alınamadı:", error.message);
        }

        const executorName = executor
          ? `${executor.tag} (${executor.id})`
          : "Bilinmiyor";

        await sendLog(newRole.client, newRole.guild.id, {
          title: "Rol Rengi Değiştirildi",
          color: 0xf39c12,
          fields: [
            { name: "Rol", value: `<@&${newRole.id}>`, inline: true },
            { name: "Eski Renk", value: oldRole.hexColor, inline: true },
            { name: "Yeni Renk", value: newRole.hexColor, inline: true },
            { name: "Yetkili", value: executorName, inline: false },
            { name: "Tarih / Saat", value: formatDate(new Date()), inline: false },
          ],
        });
      }
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] RoleUpdate hatası:", error.message);
    }
  },
};
