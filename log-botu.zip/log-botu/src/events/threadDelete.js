const { Events, AuditLogEvent } = require("discord.js");
const { sendLog } = require("../utils/sendLog");
const { formatDate } = require("../utils/formatDate");

module.exports = {
  name: Events.ThreadDelete,
  once: false,
  async execute(thread) {
    try {
      let executor = null;
      try {
        const auditLogs = await thread.guild.fetchAuditLogs({
          type: AuditLogEvent.ThreadDelete,
          limit: 5,
        });
        const entry = auditLogs.entries.first();
        if (entry) executor = entry.executor;
      } catch (error) {
        if (error.code !== 50013) console.warn("[BURAYA_BOTUNUZUN_ADI] Denetim kaydı alınamadı:", error.message);
      }

      const executorName = executor
        ? `${executor.tag} (${executor.id})`
        : "Bilinmiyor";

      await sendLog(thread.client, thread.guild.id, {
        title: "Thread Silindi",
        color: 0xe74c3c,
        fields: [
          { name: "Thread Adı", value: thread.name, inline: true },
          { name: "Kanal", value: `<#${thread.parentId}>`, inline: true },
          { name: "Yetkili", value: executorName, inline: false },
          { name: "Tarih / Saat", value: formatDate(new Date()), inline: false },
        ],
      });
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] ThreadDelete hatası:", error.message);
    }
  },
};
