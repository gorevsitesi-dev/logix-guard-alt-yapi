const { Events, AuditLogEvent } = require("discord.js");
const { sendLog } = require("../utils/sendLog");
const { formatDate } = require("../utils/formatDate");
const { getChannelTypeName } = require("../utils/channelTypes");

module.exports = {
  name: Events.ChannelDelete,
  once: false,
  async execute(channel) {
    try {
      let executor = null;

      try {
        const auditLogs = await channel.guild.fetchAuditLogs({
          type: AuditLogEvent.ChannelDelete,
          limit: 5,
        });

        const entry = auditLogs.entries.first();
        if (entry) {
          executor = entry.executor;
        }
      } catch (error) {
        if (error.code !== 50013) console.warn("[BURAYA_BOTUNUZUN_ADI] Denetim kaydı alınamadı:", error.message);
      }

      const executorName = executor
        ? `${executor.tag} (${executor.id})`
        : "Bilinmiyor";

      await sendLog(channel.client, channel.guild.id, {
        title: "Kanal Silindi",
        color: 0xe74c3c,
        fields: [
          { name: "Kanal Adı", value: channel.name, inline: true },
          { name: "Kanal Tipi", value: getChannelTypeName(channel.type), inline: true },
          { name: "Yetkili", value: executorName, inline: false },
          { name: "Tarih / Saat", value: formatDate(new Date()), inline: false },
        ],
      });
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] Kanal silme log hatası:", error.message);
    }
  },
};
