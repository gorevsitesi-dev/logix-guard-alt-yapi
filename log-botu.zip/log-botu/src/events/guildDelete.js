const { Events } = require("discord.js");
const { removeGuild } = require("../utils/guildConfig");

module.exports = {
  name: Events.GuildDelete,
  once: false,
  async execute(guild) {
    try {
      removeGuild(guild.id);
      console.log(`[BURAYA_BOTUNUZUN_ADI] Sunucudan ayrıldı: ${guild.name} (${guild.id})`);
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] GuildDelete hatası:", error.message);
    }
  },
};
