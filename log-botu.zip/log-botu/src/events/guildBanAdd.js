const { Events, AuditLogEvent } = require("discord.js");
const { sendLog } = require("../utils/sendLog");
const { formatDate } = require("../utils/formatDate");

module.exports = {
  name: Events.GuildBanAdd,
  once: false,
  async execute(ban) {
    try {
      let executor = null;

      try {
        const auditLogs = await ban.guild.fetchAuditLogs({
          type: AuditLogEvent.MemberBanAdd,
          limit: 5,
        });

        const entry = auditLogs.entries.find(
          (e) => e.target?.id === ban.user.id
        );

        if (entry) {
          executor = entry.executor;
        }
      } catch (error) {
        if (error.code !== 50013) console.warn("[BURAYA_BOTUNUZUN_ADI] Denetim kaydı alınamadı:", error.message);
      }

      const executorName = executor
        ? `${executor.tag} (${executor.id})`
        : "Bilinmiyor";

      await sendLog(ban.client, ban.guild.id, {
        title: "Kullanıcı Banlandı",
        color: 0xe74c3c,
        fields: [
          {
            name: "Banlanan Kullanıcı",
            value: `${ban.user.tag} (${ban.user.id})`,
            inline: true,
          },
          { name: "Yetkili", value: executorName, inline: true },
          { name: "Tarih / Saat", value: formatDate(new Date()), inline: false },
        ],
      });
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] Ban log hatası:", error.message);
    }
  },
};
