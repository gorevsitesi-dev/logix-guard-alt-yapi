const { Events, EmbedBuilder, ChannelType } = require("discord.js");

module.exports = {
  name: Events.GuildCreate,
  once: false,
  async execute(guild) {
    try {
      console.log(`[BURAYA_BOTUNUZUN_ADI] Yeni sunucuya eklendi: ${guild.name} (${guild.id})`);

      const owner = await guild.fetchOwner();

      const embed = new EmbedBuilder()
        .setColor(0x0a1a3a)
        .setTitle("BURAYA_BOTUNUZUN_ADI Sunucunuza Katıldı!")
        .setDescription(
          "Merhaba! Ben **BURAYA_BOTUNUZUN_ADI**, gelişmiş sunucu log botuyum.\n\n" +
          "Kullanmaya başlamak için bir metin kanalı seçin ve aşağıdaki komutu kullanın:"
        )
        .addFields(
          {
            name: "Kurulum Komutu",
            value: "`/log-kanal #kanal`",
            inline: false,
          },
          {
            name: "Örnek",
            value: "`/log-kanal #loglar`",
            inline: false,
          },
          {
            name: "Özellikler",
            value:
              "• Rol ekleme / çıkarma logları\n" +
              "• Mesaj silme / düzenleme logları\n" +
              "• Kanal oluşturma / silme logları\n" +
              "• Ban / ban kaldırma logları\n" +
              "• Audit log entegrasyonu",
            inline: false,
          }
        )
        .setFooter({
          text: "BURAYA_BOTUNUZUN_ADI • Gelişmiş Sunucu Log Sistemi",
        })
        .setTimestamp();

      const systemChannel = guild.systemChannel;
      if (systemChannel) {
        try {
          await systemChannel.send({ embeds: [embed] });
        } catch {
          // sistem kanalina yazilamadiysa sessiz gec
        }
      }

      if (!systemChannel) {
        try {
          const channels = await guild.channels.fetch();
          const textChannel = channels
            .filter((c) => c.type === ChannelType.GuildText)
            .sort((a, b) => a.position - b.position)
            .first();
          if (textChannel) {
            await textChannel.send({ embeds: [embed] });
          }
        } catch {
          // hic uygun kanal yoksa sessiz gec
        }
      }

      try {
        await owner.send({
          embeds: [
            new EmbedBuilder()
              .setColor(0x0a1a3a)
              .setTitle("BURAYA_BOTUNUZUN_ADI Kurulum")
              .setDescription(
                `**${guild.name}** sunucunuza eklendim!\n\n` +
                "Kurulum için sunucuda `/log-kanal #kanal` komutunu kullanın."
              )
              .setFooter({
                text: "BURAYA_BOTUNUZUN_ADI • Gelişmiş Sunucu Log Sistemi",
              })
              .setTimestamp(),
          ],
        });
      } catch {
        // DM kapalıysa sessiz geç
      }
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] GuildCreate hatası:", error.message);
    }
  },
};
