const { Events, AuditLogEvent } = require("discord.js");
const { sendLog } = require("../utils/sendLog");
const { formatDate } = require("../utils/formatDate");

module.exports = {
  name: Events.GuildUpdate,
  once: false,
  async execute(oldGuild, newGuild) {
    try {
      if (oldGuild.name !== newGuild.name) {
        let executor = null;
        try {
          const auditLogs = await newGuild.fetchAuditLogs({
            type: AuditLogEvent.GuildUpdate,
            limit: 5,
          });
          const entry = auditLogs.entries.first();
          if (entry) executor = entry.executor;
        } catch (error) {
          if (error.code !== 50013) console.warn("[BURAYA_BOTUNUZUN_ADI] Denetim kaydı alınamadı:", error.message);
        }

        const executorName = executor
          ? `${executor.tag} (${executor.id})`
          : "Bilinmiyor";

        await sendLog(newGuild.client, newGuild.id, {
          title: "Sunucu Adı Değiştirildi",
          color: 0xf39c12,
          fields: [
            { name: "Eski Ad", value: oldGuild.name, inline: true },
            { name: "Yeni Ad", value: newGuild.name, inline: true },
            { name: "Yetkili", value: executorName, inline: false },
            { name: "Tarih / Saat", value: formatDate(new Date()), inline: false },
          ],
        });
      }
    } catch (error) {
      console.error("[BURAYA_BOTUNUZUN_ADI] GuildUpdate hatası:", error.message);
    }
  },
};
