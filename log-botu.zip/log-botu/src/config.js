require("dotenv").config();

const token = process.env.TOKEN;

if (!token) {
  console.error("[BURAYA_BOTUNUZUN_ADI] KRITIK: .env dosyasinda TOKEN bulunamadi!");
  console.error("[BURAYA_BOTUNUZUN_ADI] .env.example dosyasini .env olarak kopyalayip tokeninizi girin.");
  process.exit(1);
}

module.exports = {
  token,
  defaultLogChannel: process.env.LOG_CHANNEL_ID || null,
};
