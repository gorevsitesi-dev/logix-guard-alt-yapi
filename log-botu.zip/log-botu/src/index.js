const { Client, GatewayIntentBits, Collection, MessageFlags } = require("discord.js");
const fs = require("fs");
const path = require("path");
const config = require("./config");

process.on("unhandledRejection", (error) => {
  console.error("[BURAYA_BOTUNUZUN_ADI] Yakalanamayan promise hatasi:", error.message);
  if (error.stack) console.error(error.stack);
});

process.on("uncaughtException", (error) => {
  console.error("[BURAYA_BOTUNUZUN_ADI] Yakalanamayan hata:", error.message);
  if (error.stack) console.error(error.stack);
});

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildEmojisAndStickers,
  ],
});

client.commands = new Collection();

const commandsPath = path.join(__dirname, "commands");
if (fs.existsSync(commandsPath)) {
  const commandFiles = fs
    .readdirSync(commandsPath)
    .filter((file) => file.endsWith(".js"));

  for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    try {
      const command = require(filePath);
      if (command.data && command.execute) {
        client.commands.set(command.data.name, command);
        console.log(`[BURAYA_BOTUNUZUN_ADI] Komut yüklendi: /${command.data.name}`);
      }
    } catch (error) {
      console.error(`[BURAYA_BOTUNUZUN_ADI] Komut yüklenemedi: ${file} -`, error.message);
    }
  }
}

const eventsPath = path.join(__dirname, "events");
if (fs.existsSync(eventsPath)) {
  const eventFiles = fs
    .readdirSync(eventsPath)
    .filter((file) => file.endsWith(".js"));

  for (const file of eventFiles) {
    const filePath = path.join(eventsPath, file);
    try {
      const event = require(filePath);
      if (!event.name || typeof event.execute !== "function") {
        console.error(`[BURAYA_BOTUNUZUN_ADI] Geçersiz event dosyasi: ${file}`);
        continue;
      }

      if (event.once) {
        client.once(event.name, (...args) => event.execute(...args));
      } else {
        client.on(event.name, (...args) => event.execute(...args));
      }

      console.log(`[BURAYA_BOTUNUZUN_ADI] Event yüklendi: ${file}`);
    } catch (error) {
      console.error(`[BURAYA_BOTUNUZUN_ADI] Event yüklenemedi: ${file} -`, error.message);
    }
  }
}

client.on("interactionCreate", async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction);
  } catch (error) {
    console.error(`[BURAYA_BOTUNUZUN_ADI] /${interaction.commandName} hatasi:`, error.message);
    const replyOpts = {
      content: "Komut çalıştırılırken bir hata oluştu.",
      flags: MessageFlags.Ephemeral,
    };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(replyOpts);
    } else {
      await interaction.reply(replyOpts);
    }
  }
});

client.on("rateLimit", (rateLimitData) => {
  console.warn(
    `[BURAYA_BOTUNUZUN_ADI] Rate limit uyarisi: ${rateLimitData.route} icin ${rateLimitData.timeout}ms beklenecek.`
  );
});

client.on("shardDisconnect", (closeEvent, shardId) => {
  console.error(
    `[BURAYA_BOTUNUZUN_ADI] Baglanti koptu! Shard ${shardId} - Kod: ${closeEvent.code} - Sebep: ${closeEvent.reason || "Bilinmiyor"}`
  );
});

client.on("shardReconnecting", (shardId) => {
  console.log(`[BURAYA_BOTUNUZUN_ADI] Tekrar baglaniyor... Shard ${shardId}`);
});

client.on("shardResume", (shardId, replayedEvents) => {
  console.log(`[BURAYA_BOTUNUZUN_ADI] Baglanti yeniden kuruldu. Shard ${shardId} - ${replayedEvents} olay tekrar oynatildi.`);
});

client.on("invalidRequestWarning", (data) => {
  console.warn(`[BURAYA_BOTUNUZUN_ADI] Gecersiz API istegi uyarisi: ${data.count} istek`);
});

let healthCheckInterval;

client.once("ready", () => {
  healthCheckInterval = setInterval(() => {
    if (client.ws && (client.ws.ping === -1 || client.ws.ping === null)) {
      console.warn("[BURAYA_BOTUNUZUN_ADI] WebSocket baglantisi koptu, yeniden baglaniyor...");
    }
  }, 60000);
});

process.on("SIGINT", () => {
  clearInterval(healthCheckInterval);
  process.exit(0);
});

process.on("SIGTERM", () => {
  clearInterval(healthCheckInterval);
  process.exit(0);
});

client.login(config.token).catch((error) => {
  console.error("[BURAYA_BOTUNUZUN_ADI] Bot baslatilamadi:", error.message);
  process.exit(1);
});
